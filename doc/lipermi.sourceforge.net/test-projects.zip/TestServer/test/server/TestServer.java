package test.server;

import java.io.IOException;
import java.net.Socket;

import net.sf.lipermi.exception.LipeRMIException;
import net.sf.lipermi.handler.CallHandler;
import net.sf.lipermi.handler.CallLookup;
import net.sf.lipermi.handler.filter.GZipFilter;
import net.sf.lipermi.net.IServerListener;
import net.sf.lipermi.net.Server;

import test.common.AnotherObject;
import test.common.TestService;

public class TestServer implements TestService {

	CallHandler callHandler;
	
	public String letsDoIt() {
		System.out.println("letsDoIt() done.");
		Socket clientSocket = CallLookup.getCurrentSocket();
		System.out.println("My client: " + clientSocket.getRemoteSocketAddress());
		return "server saying hi";
	}
	
	public TestServer() {
		
		
		System.out.println("Creating Server");
		Server server = new Server();
		System.out.println("Creating CallHandler");
		callHandler = new CallHandler();
		try {
			System.out.println("Registrating implementation");
			callHandler.registerGlobal(TestService.class, this);
			System.out.println("Binding");
			server.addServerListener(new IServerListener() {
				public void clientConnected(Socket socket) {
					System.out.println("Client connected: " + socket.getInetAddress());
				}

				public void clientDisconnected(Socket socket) {
					System.out.println("Client disconnected: " + socket.getInetAddress());
				}
			});
			server.bind(1234, callHandler, new GZipFilter());
			System.out.println("Server listening");
		} catch (LipeRMIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		new TestServer();
	}

	int anotherNumber = 0;
	
	public AnotherObject getAnotherObject() {
		System.out.println("building AnotherObject with anotherNumber=" + anotherNumber);
		AnotherObject ao = new AnotherObjectImpl(anotherNumber++);
		try {
			callHandler.exportObject(AnotherObject.class, ao);
		} catch (LipeRMIException e) {
			e.printStackTrace();
		}
		return ao;
	}

	public void throwAExceptionPlease() {
		throw new AssertionError("ok, ok");
	}
}
