package test.common;

public interface TestService {

	public String letsDoIt();
	
	public AnotherObject getAnotherObject();
	
	public void throwAExceptionPlease();
}
