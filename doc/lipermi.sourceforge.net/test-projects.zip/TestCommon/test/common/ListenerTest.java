package test.common;

import java.io.Serializable;

public interface ListenerTest extends Serializable {

	void makingSomeCallback(String str);
	
}
